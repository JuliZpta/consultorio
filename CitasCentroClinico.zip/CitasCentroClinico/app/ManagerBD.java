public class ManagerBD {
}
