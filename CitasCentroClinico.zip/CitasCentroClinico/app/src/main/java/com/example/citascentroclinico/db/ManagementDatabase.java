package com.example.citascentroclinico.db;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

public class ManagementDatabase {

    private Database database;
    private SQLiteDatabase db;

    public ManagementDatabase(Database database) {
        this.database = database;
        this.db = database.getWritableDatabase();
    }


    public void insertarEspecialidad(int id, String nombre) {
        ContentValues values = new ContentValues();
        values.put("id", id);
        values.put("nombre", nombre);
        db.insert("Especialidad", null, values);
    }


    public void insertarMedico(int cedulaMed, String nombre, int consultorio, int idEspecialidad) {
        ContentValues values = new ContentValues();
        values.put("cedulaMed", cedulaMed);
        values.put("nombre", nombre);
        values.put("consultorio", consultorio);
        values.put("id_especialidad", idEspecialidad);
        db.insert("Medico", null, values);
    }

    public void insertarCita(String fecha, String hora, int cedula, int cedulaMed) {
        ContentValues values = new ContentValues();
        values.put("fecha", fecha);
        values.put("hora", hora);
        values.put("cedula", cedula);
        values.put("cedulaMed", cedulaMed);
        db.insert("Cita", null, values);
    }


    public void insertarUsuario(int cedula, String nombre, String telefono) {
        ContentValues values = new ContentValues();
        values.put("cedula", cedula);
        values.put("nombre", nombre);
        values.put("telefono", telefono);
        db.insert("Usuario", null, values);
    }

    public void insertarDatosEjemplo() {
        // Insertar especialidades
        insertarEspecialidad(1, "Odontología");
        insertarEspecialidad(2, "Medicina general");
        insertarEspecialidad(3, "Laboratorio");

        // Insertar médicos
        insertarMedico(101, "Dr. Juan Pérez", 101, 1);
        insertarMedico(102, "Dr. Luis García", 102, 1);
        insertarMedico(103, "Dra. Marta Ríos", 103, 1);
        insertarMedico(104, "Dr. Carlos Mendoza", 104, 2);
        insertarMedico(105, "Dra. Ana López", 105, 2);
        insertarMedico(106, "Dr. Pedro Jiménez", 106, 2);
        insertarMedico(107, "Dra. Laura Vargas", 107, 3);
        insertarMedico(108, "Dr. Mario Rivera", 108, 3);
        insertarMedico(109, "Dra. Silvia Cruz", 109, 3);
    }
}
